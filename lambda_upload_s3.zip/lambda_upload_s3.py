import json
import urllib.parse
import boto3
import base64

print('Loading function')
# session = boto3.Session(profile_name='personal')
# s3 = session.client('s3')

s3 = boto3.client('s3', endpoint_url='http://localhost:4574')


def lambda_handler(event, context):
    # raise Exception('Something went wrong')
    print("Received event: " + json.dumps(event, indent=2))

    # Get the object from the event and show its content type
    # bucket = event['Records'][0]['s3']['bucket']['name']
    # key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    try:
        image_data = base64.b64decode(event['image_date'])
        response = s3.put_object(
            Body=image_data,
            Bucket='doyouknowme',
            Key='pokemon.jpeg',
            ContentType='image/jpeg'
        )

        print(response)
        return response

        # response = s3.get_object(Bucket=bucket, Key=key)
        # print("CONTENT TYPE: " + response['ContentType'])
        # return response['ContentType']
        # print("Received event: " + json.dumps(event, indent=2))
        # print("value1 = " + event['key1'])
        # print("value2 = " + event['key2'])
        # print("value3 = " + event['key3'])
        # return event['key1']  # Echo back the first key value
    except Exception as e:
        print(e)
        # print(
        #     'Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as '
        #     'this function.'.format(
        #         key, bucket))
        raise e
